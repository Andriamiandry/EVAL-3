# Copyright (c) 2020, Frappe Technologies and Contributors
# See license.txt
# import frappe
import unittest

from frappe.tests import IntegrationTestCase


class TestBankStatementImport(IntegrationTestCase):
	pass
